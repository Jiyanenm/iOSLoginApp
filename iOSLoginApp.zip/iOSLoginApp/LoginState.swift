import Foundation

struct LoginState {
    var email: String = ""
    var password: String = ""
    var rememberMe: Bool = false
    var isLoading: Bool = false
    var error: String? = nil
    var failureCount: Int = 0
    var isLocked: Bool = false
    var isOffline: Bool = false
    var navigate: Bool = false
    
    var isButtonEnabled: Bool {
        return email.contains("@") &&
               password.count >= 6 &&
               !isLocked
    }
}

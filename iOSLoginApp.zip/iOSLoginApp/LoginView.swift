import SwiftUI

struct LoginView: View {
    @StateObject private var vm = LoginViewModel()
    
    var body: some View {
        VStack(spacing: 16) {
            
            TextField("Email", text: $vm.state.email)
                .textFieldStyle(.roundedBorder)
                .autocapitalization(.none)
                .accessibilityIdentifier("email_field")

            SecureField("Password", text: $vm.state.password)
                .textFieldStyle(.roundedBorder)
                .accessibilityIdentifier("password_field")

            Toggle(isOn: $vm.state.rememberMe) {
                Text("Remember Me")
            }
            .accessibilityIdentifier("remember_me_toggle")

            Button {
                vm.login()
            } label: {
                if vm.state.isLoading {
                    ProgressView()
                } else {
                    Text("Login")
                }
            }
            .disabled(!vm.state.isButtonEnabled)
            .buttonStyle(.borderedProminent)
            .accessibilityIdentifier("login_button")

            if let error = vm.state.error {
                Text(error)
                    .foregroundColor(.red)
            }

            if vm.state.isLocked {
                Text("Account locked after 3 failures")
                    .foregroundColor(.red)
            }

            if vm.state.isOffline {
                Text("Offline: check your connection")
            }
        }
        .padding()
    }
}

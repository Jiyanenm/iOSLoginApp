import Foundation
import Combine

@MainActor
class LoginViewModel: ObservableObject {
    
    @Published var state = LoginState()
    
    private let authService: AuthService
    private let networkMonitor: NetworkMonitor
    
    init(
        authService: AuthService = AuthService(),
        networkMonitor: NetworkMonitor = NetworkMonitor()
    ) {
        self.authService = authService
        self.networkMonitor = networkMonitor
        
        networkMonitor.$isOnline
            .sink { [weak self] online in
                self?.state.isOffline = !online
            }
            .store(in: &cancellables)
    }
    
    private var cancellables: Set<AnyCancellable> = []
    
    func login() {
        guard !state.isLocked, !state.isOffline else {
            return
        }
        
        state.isLoading = true
        state.error = nil
        
        Task {
            let success = await authService.login(
                email: state.email,
                password: state.password
            )
            
            state.isLoading = false
            
            if success {
                if state.rememberMe {
                    authService.saveToken("sample-token")
                }
                
                state.navigate = true
                state.failureCount = 0
                
            } else {
                state.failureCount += 1
                state.error = "Invalid credentials"
                
                if state.failureCount >= 3 {
                    state.isLocked = true
                }
            }
        }
    }
}

import Combine

class NetworkMonitor: ObservableObject {
    @Published var isOnline: Bool = true
    
    func setStatus(_ status: Bool) {
        isOnline = status
    }
}

import SwiftUI

@main
struct iOSLoginAppApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}

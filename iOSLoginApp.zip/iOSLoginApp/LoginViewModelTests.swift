import XCTest
@testable import iOSLoginApp

final class LoginViewModelTests: XCTestCase {

    func testSuccessfulLogin() async {
        let vm = LoginViewModel()
        
        vm.state.email = "test@example.com"
        vm.state.password = "password123"
        
        vm.login()
        try? await Task.sleep(nanoseconds: 400_000_000)
        
        XCTAssertTrue(vm.state.navigate)
        XCTAssertEqual(0, vm.state.failureCount)
    }
    
    func testThreeFailuresLocksAccount() async {
        let vm = LoginViewModel()
        
        vm.state.email = "test@example.com"
        vm.state.password = "wrongpass"
        
        for _ in 0..<3 {
            vm.login()
            try? await Task.sleep(nanoseconds: 400_000_000)
        }
        
        XCTAssertTrue(vm.state.isLocked)
    }
}

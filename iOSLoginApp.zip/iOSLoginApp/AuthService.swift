import Foundation

class AuthService {
    private let correctPassword = "password123"
    
    func login(email: String, password: String) async -> Bool {
        try? await Task.sleep(nanoseconds: 300_000_000) // 300ms
        return password == correctPassword
    }
    
    func saveToken(_ token: String) {
        UserDefaults.standard.set(token, forKey: "auth_token")
    }
    
    func getToken() -> String? {
        return UserDefaults.standard.string(forKey: "auth_token")
    }
}

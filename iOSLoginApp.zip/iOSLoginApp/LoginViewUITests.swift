
final class LoginViewUITests: XCTestCase {

    func testButtonDisabledInitially() {
        let app = XCUIApplication()
        app.launch()

        XCTAssertFalse(app.buttons["login_button"].isEnabled)
    }
    
    func testValidInputEnablesButton() {
        let app = XCUIApplication()
        app.launch()

        let email = app.textFields["email_field"]
        let password = app.secureTextFields["password_field"]

        email.tap()
        email.typeText("test@example.com")

        password.tap()
        password.typeText("password123")

        XCTAssertTrue(app.buttons["login_button"].isEnabled)
    }
}
